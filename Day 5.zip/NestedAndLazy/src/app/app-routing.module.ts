import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { AuthenticateGuardService } from './services/authenticate-guard.service';


const routes: Routes = [
    {
        path: 'home', component: HomeComponent
    }, {
        path: 'about', component: AboutComponent
    },                                      //url to module file # Module class name
    // { path: 'products', loadChildren: './products/products.module#ProductsModule' },
    // Angular 8 :
    {
        path: 'products',
        canActivate: [AuthenticateGuardService],
        canDeactivate: [],
        loadChildren: () => import('./products/products.module').then(m => m.ProductsModule)
    },

    {
        path: '', pathMatch: 'full', redirectTo: 'home'
    },
    {
        path: '**', redirectTo: 'home'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
