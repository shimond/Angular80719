import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { filter, map, tap } from 'rxjs/operators';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'nestedAndLazy';

    error$: Observable<string>;
    constructor(private activedRoute: ActivatedRoute) {
    }

    ngOnInit() {
        this.error$ = this.activedRoute.queryParams
            .pipe(filter(o => o.redirectFrom), map(o => '403 from - ' + o.redirectFrom));

        this.activedRoute.queryParams
            .pipe(tap(c => console.log(c)), filter(o => o.redirectFrom), map(o => '403 from - ' + o.redirectFrom)).subscribe(o => console.log(o));
    }
}
