import { ProductsHomeComponent } from './components/products-home/products-home.component';
import { ProductsPage1Component } from './components/products-page1/products-page1.component';
import { ProductsPage2Component } from './components/products-page2/products-page2.component';

export const PRODUCTS_ROUTES = [{
    path: '', component: ProductsHomeComponent, children: [
        { path: '', component: ProductsPage1Component },
        { path: 'p2', component: ProductsPage2Component },
    ]
},]