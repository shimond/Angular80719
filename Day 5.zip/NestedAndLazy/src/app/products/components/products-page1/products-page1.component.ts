import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { Observable } from 'rxjs';
import { Product } from 'src/app/models/product.model';

@Component({
    selector: 'app-products-page1',
    templateUrl: './products-page1.component.html',
    styleUrls: ['./products-page1.component.scss']
})
export class ProductsPage1Component implements OnInit {
    products$: Observable<Product[]>;
    editableProduct: Product = null;
    error: any[] = [];
    constructor(private productsService: ProductsService) { }

    ngOnInit() {
        this.products$ = this.productsService.allProducts$;
    }
    async deleteItem(p: Product) {
        await this.productsService.deleteProduct(p);
        alert('Product deleted..');

    }
    onEdit(p: Product) {
        this.editableProduct = p;
    }
    async onSaveRequested(item: Product, isNew: boolean) {
        try {
            if (isNew) {
                await this.productsService.insertProduct(item);
            } else {
                await this.productsService.updateProduct(item);
            }
        } catch (error) {
            this.error = Object.values(error.error);
            console.log(error);
        }


    }

}
