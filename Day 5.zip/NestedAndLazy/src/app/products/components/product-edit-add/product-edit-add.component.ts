import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Product } from 'src/app/models/product.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-product-edit-add',
    templateUrl: './product-edit-add.component.html',
    styleUrls: ['./product-edit-add.component.scss']
})
export class ProductEditAddComponent implements OnInit, OnChanges {

    productForm: FormGroup;
    @Input() product: Product;
    @Output() saveRequested = new EventEmitter<Product>();

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        if (!this.product) {
            this.productForm = this.formBuilder.group({
                id: [-1],
                name: ['', Validators.required],
                price: [null, Validators.compose([Validators.required, Validators.min(0)])],
                imageUrl: []
            });
        }
    }

    ngOnChanges() {
        if (this.product) {
            this.productForm = this.formBuilder.group({
                id: [this.product.id],
                name: [this.product.name, Validators.required],
                price: [this.product.price, Validators.compose([Validators.required, Validators.min(0)])],
                imageUrl: [this.product.imageUrl]
            });
        }
    }

    onSubmit() {
        if (this.productForm.valid) {
            this.saveRequested.emit(this.productForm.value);
        }
    }
}
