import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { filter, map, tap } from 'rxjs/operators';
import { ProductsService } from '../../services/products.service';

@Component({
    selector: 'app-products-home',
    templateUrl: './products-home.component.html',
    styleUrls: ['./products-home.component.scss']
})
export class ProductsHomeComponent implements OnInit {

    constructor(private productsService: ProductsService) { }
    ngOnInit(): void {
        this.productsService.loadAll();
    }

}
