import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-page2',
  templateUrl: './products-page2.component.html',
  styleUrls: ['./products-page2.component.scss']
})
export class ProductsPage2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
