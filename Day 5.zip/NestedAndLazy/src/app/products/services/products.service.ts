import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Product } from 'src/app/models/product.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { tap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class ProductsService {

    private allProductsSubject$ = new BehaviorSubject<Product[]>([]);

    get allProducts$() {
        return this.allProductsSubject$.asObservable();
    }

    loadAll() {
        this.http.get<Product[]>(`${environment.apiUrl}products`).subscribe(list => this.allProductsSubject$.next(list));
    }

    deleteProduct(p: Product) {
        return this.http.delete<any>(`${environment.apiUrl}products/${p.id}`)
            .pipe(tap(() => this.loadAll()))
            .toPromise();
    }

    insertProduct(p: Product) {
        return this.http.post<Product>(`${environment.apiUrl}products`, p)
            .pipe(tap(() => this.loadAll()))
            .toPromise();
    }

    updateProduct(p: Product) {
        return this.http.put<Product>(`${environment.apiUrl}products/${p.id}`, p)
            .pipe(tap(() => this.loadAll()))
            .toPromise();
    }

    constructor(private http: HttpClient) { }
}
