import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsHomeComponent } from './components/products-home/products-home.component';
import { ProductsPage1Component } from './components/products-page1/products-page1.component';
import { ProductsPage2Component } from './components/products-page2/products-page2.component';
import { RouterModule } from '@angular/router';
import { PRODUCTS_ROUTES } from './products-module.routings';
import { ProductEditAddComponent } from './components/product-edit-add/product-edit-add.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
    declarations: [ProductsHomeComponent, ProductsPage1Component, ProductsPage2Component, ProductEditAddComponent],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        RouterModule.forChild(PRODUCTS_ROUTES)
    ]
})
export class ProductsModule { }


