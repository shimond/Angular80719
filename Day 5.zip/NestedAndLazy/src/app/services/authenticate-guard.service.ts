import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthenticateGuardService implements CanActivate {
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        console.log('Ask to navigate...', { route, state });
        
        if(localStorage.getItem('utoken'))
        {
            return true;
        }
        
        return this.router.parseUrl('/home?e=403&redirectFrom=' + state.url);
    }

    constructor(private router: Router) { }
}
