﻿using FirstCoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstCoreApp.Contracts
{
    public interface IProductRepository
    {
        bool IsProductExists(int id);

        List<Product> GetAll();

        Task<Product> GetProductById(int id);

        Product AddProduct(Product p);

        void DeleteProduct(int id);

        Product UpdateProduct(Product p);

        void Save();

    }
}
