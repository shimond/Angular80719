﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstCoreApp.Models.Context
{
    public class MyAppContext : DbContext
    {
        public DbSet<Product> Products { get; set; }


        public MyAppContext(DbContextOptions<MyAppContext> options): base(options)
        {
        }
    }
}
