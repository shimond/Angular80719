﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FirstCoreApp
{
    public class PriceValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            bool isNum = int.TryParse(value.ToString(), out int price);
            if (isNum)
            {
                return price % 3 == 0;
            }
            return false;
        }

        public PriceValidationAttribute()
        {
            this.ErrorMessage = "Price not valid (% 3 !=0)";
        }
    }
}
