﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstCoreApp.Contracts;
using FirstCoreApp.Models;
using FirstCoreApp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FirstCoreApp.Controllers
{
    // Install-Package Microsoft.EntityFrameworkCore.SqlServer -version 2.1.1
    [Route("api/products")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductRepository _productRepository;

        [HttpGet]
        public ActionResult<List<Product>> GetAllProducts()
        {
            return Ok(_productRepository.GetAll());
        }

        [HttpGet("{idOfProduct}")]
        public async Task<ActionResult<Product>> GetById(int idOfProduct)
        {
            var item = await _productRepository.GetProductById(idOfProduct);
            if (item != null)
            {
                return Ok(item);
            }
            return NotFound();
        }

        [HttpPost]
        public ActionResult<Product> AddNewProduct(Product p)
        {
            _productRepository.AddProduct(p);
            return Created("/api/products/" + p.ID, p);
        }

        [HttpDelete("{pID}")]
        public  async Task<ActionResult> DeleteProduct(int pID)
        {
            var item =  await _productRepository.GetProductById(pID);
            if (item == null)
            {
                return NotFound();
            }

            _productRepository.DeleteProduct(pID);
            return Ok();

        }


        [HttpPut("{id}")]
        public ActionResult UpdateProduct(int id, [FromBody]Product product)
        {
            var isProductExists = _productRepository.IsProductExists(id);
            if (!isProductExists)
            {
                return NotFound();
            }

            var productAfterUpdated = _productRepository.UpdateProduct(product);
            return Ok(productAfterUpdated);

        }

        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
    }
}