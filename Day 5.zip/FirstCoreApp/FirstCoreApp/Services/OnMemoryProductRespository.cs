﻿using FirstCoreApp.Contracts;
using FirstCoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstCoreApp.Services
{
    public class OnMemoryProductRespository : IProductRepository
    {
        private static List<Product> _list = new List<Product>() {
                new Product { ID = 1, Name = "Bamaba", Price = 12.6, ImageUrl = "https://www.dutyfree.co.il/media/catalog/product/cache/3/image/9df78eab33525d08d6e5fb8d27136e95/4/2/42436__42438.jpg"},
                new Product { ID = 2, Name = "kinder bueno", Price = 10.6, ImageUrl = "https://images-na.ssl-images-amazon.com/images/I/61rns2a7wcL._SX355_.jpg"},
                new Product { ID = 3, Name = "Bisli", Price = 2.6, ImageUrl = "https://osemcat.signature-it.com//images/Fittings/osem-hq/Upload_Pictures/Prod_Pic/6930925/Custom/6930925_7290000066196_1.png"},
                new Product { ID = 4, Name = "Kefli", Price = 7.2, ImageUrl = "https://www.amihaimcandies.com/wp-content/uploads/2017/09/7290000110851.jpg"},

        };

        public Product AddProduct(Product p)
        {
            var lastId = _list.Last().ID;
            p.ID = lastId + 1;
            _list.Add(p);
            return p;
        }

        public void DeleteProduct(int id)
        {
            var itemToDelete = _list.FirstOrDefault(x => x.ID == id);
            if(itemToDelete == null)
            {
                throw new NullReferenceException("Product id not found..");
            }
            _list.Remove(itemToDelete);
        }

        public List<Product> GetAll()
        {
            return _list;
        }

        public Task<Product> GetProductById(int id)
        {
            return Task.Factory.StartNew(()=> _list.FirstOrDefault(x => id == x.ID));
        }

        public bool IsProductExists(int id)
        {
            return _list.Any(x => x.ID == id);
        }

        public void Save()
        {
            // throw new NotImplementedException();
        }

        public Product UpdateProduct(Product p)
        {

            var itemToUpdate = _list.FirstOrDefault(x => x.ID == p.ID);
            if (itemToUpdate == null)
            {
                throw new NullReferenceException("Product id not found..");
            }
            itemToUpdate.ImageUrl = p.ImageUrl;
            itemToUpdate.Name = p.Name;
            itemToUpdate.Price = p.Price;

            return itemToUpdate;
        }
    }
}
