﻿using FirstCoreApp.Contracts;
using FirstCoreApp.Models;
using FirstCoreApp.Models.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstCoreApp.Services
{
    public class SqlProductRespository : IProductRepository
    {
        private MyAppContext _db;
        public Product AddProduct(Product p)
        {
            p.ID = 0;
            _db.Products.Add(p);
            _db.SaveChanges();
            return p;
        }

        public void DeleteProduct(int id)
        {
            var productToDelete = _db.Products.Find(id);
            _db.Products.Remove(productToDelete);
            _db.SaveChanges();
        }

        public List<Product> GetAll()
        {
            return _db.Products.ToList();
        }

        public Task<Product> GetProductById(int id)
        {
            return _db.Products.FindAsync(id);
        }

        public void Save()
        {
            this._db.SaveChanges();
        }

        public Product UpdateProduct(Product p)
        {
            _db.Products.Update(p);
            _db.SaveChanges();
            return p;
        }

        public bool IsProductExists(int id)
        {
            return _db.Products.Any(x => x.ID == id);
        }

        public SqlProductRespository(MyAppContext db)
        {
            this._db = db;
        }
    }
}
